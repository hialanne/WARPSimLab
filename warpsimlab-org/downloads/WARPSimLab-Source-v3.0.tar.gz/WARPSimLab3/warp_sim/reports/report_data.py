# warp_sim/reports/report_data.py

from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class SummaryReportData:
    report_options: dict[str, Any]
    report_metadata: dict[str, Any]
    simulation_snapshot: dict[str, Any]
    results_summary: dict[str, Any]
    assumptions_summary: dict[str, Any]
    monte_carlo_summary: Optional[dict[str, Any]] = None
    historical_windows_summary: Optional[dict[str, Any]] = None
    plot_assets: dict[str, Any] = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)


@dataclass
class ReportResult:
    success: bool
    report_path: Optional[str] = None
    output_folder: Optional[str] = None
    warnings: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)