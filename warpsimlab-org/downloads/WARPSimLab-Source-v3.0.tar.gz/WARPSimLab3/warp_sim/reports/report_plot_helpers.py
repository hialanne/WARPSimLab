# report_plot_helpers.py

import os
import matplotlib.pyplot as plt
import numpy as np

from warp_sim.plots.plotOperatingBalance import draw_operating_balance
from warp_sim.plots.plotPortfolioProjection import draw_portfolio_projection
from warp_sim.plots.plotYearlyIncome import draw_yearly_income
from warp_sim.plots.portfolioPlotData import PortfolioPlotData

def _ensure_output_folder(output_folder):
    os.makedirs(output_folder, exist_ok=True)


def save_portfolio_projection_report_plot(
    output_folder,
    filename,
    years_list,
    portfolio_plot_data,
    sim_config,
    husband=None,
    wife=None,
    summary_results=None,
):
    """
    Save a portfolio projection plot for report use.

    This function intentionally does not call plt.show().
    Existing interactive plot behavior remains owned by plot_portfolio_projection().
    """
    _ensure_output_folder(output_folder)
    image_path = os.path.join(output_folder, filename)

    fig, ax = plt.subplots(figsize=(14, 8))

    if summary_results is not None:
        portfolio_plot_data = _build_portfolio_only_plot_data(
            portfolio_plot_data,
            summary_results,
        )

    try:
        draw_portfolio_projection(
            ax,
            years_list,
            portfolio_plot_data,
            sim_config=sim_config,
            annotate_plots=getattr(sim_config, "annotate_plots", False),
            sim_rebalance_string=getattr(sim_config, "sim_rebalance", ""),
            husband=husband,
            wife=wife,
        )

        fig.savefig(image_path, dpi=200, bbox_inches="tight")
        
        return image_path

    finally:
        plt.close(fig)


def save_income_projection_report_plot(
    output_folder,
    filename,
    years_to_simulate,
    net_profit,
    net_income,
    breakdown,
    taxes,
    expenses,
    husband,
    wife,
    sim_config,
):
    """
    Save an income projection plot for report use.

    This function intentionally does not call plt.show().
    Existing interactive plot behavior remains owned by plot_yearly_income().
    """
    _ensure_output_folder(output_folder)
    image_path = os.path.join(output_folder, filename)

    fig, ax = plt.subplots(figsize=(14, 7))

    try:
        draw_yearly_income(
            ax,
            years_to_simulate,
            net_profit,
            net_income,
            breakdown,
            taxes,
            expenses,
            husband,
            wife,
            sim_config,
        )

        fig.savefig(image_path, dpi=200, bbox_inches="tight")
        return image_path

    finally:
        plt.close(fig)


def save_cumulative_operating_balance_report_plot(
    output_folder,
    filename,
    years_to_simulate,
    net_profit,
    portfolio_plot_data,
    husband,
    wife,
    sim_config,
):
    """
    Save a cumulative operating balance plot for report use.

    This mirrors run_sim_operating_balance.py packaging:
      - operating_balance[0] = 0
      - operating_balance[t] = sum(net_profit[1..t]) for t >= 1

    This function intentionally does not call plt.show().
    Existing interactive plot behavior remains owned by plot_operating_balance().
    """
    _ensure_output_folder(output_folder)
    image_path = os.path.join(output_folder, filename)

    net_profit = np.array(net_profit, dtype=float)

    operating_balance = np.zeros_like(net_profit, dtype=float)
    if len(net_profit) > 1:
        operating_balance[1:] = np.cumsum(net_profit[1:])

    portfolio_value = np.array(
        portfolio_plot_data.percentiles["median"],
        dtype=float,
    )

    fig, ax = plt.subplots(figsize=(14, 7))

    try:
        draw_operating_balance(
            ax,
            years_to_simulate,
            net_profit,
            operating_balance,
            portfolio_value,
            husband,
            wife,
            sim_config,
        )

        fig.savefig(image_path, dpi=200, bbox_inches="tight")
        return image_path

    finally:
        plt.close(fig)

def _build_portfolio_only_plot_data(portfolio_plot_data, summary_results):
    """
    Build report-only portfolio plot data that excludes real estate.

    The Executive Summary pipeline may run with include_realestate=True so
    milestone tables can show Real Estate and Total Assets.

    The Portfolio Projection chart should show portfolio only:
        pre_tax_assets + post_tax_assets

    This helper avoids changing simulator output or interactive plot behavior.
    """
    pre_tax_assets = np.array(summary_results["pre_tax_assets"], dtype=float)
    post_tax_assets = np.array(summary_results["post_tax_assets"], dtype=float)
    portfolio_only = pre_tax_assets + post_tax_assets

    percentiles = dict(portfolio_plot_data.percentiles)
    percentiles["median"] = portfolio_only

    return PortfolioPlotData(
        years=portfolio_plot_data.years,
        percentiles=percentiles,
        median_without_fund_expenses=None,
        median_without_taxes=None,
        median_without_taxes_or_fund_expenses=None,
        cash=portfolio_plot_data.cash,
        bonds=portfolio_plot_data.bonds,
        realestate=None,
        pre_tax_assets=pre_tax_assets,
        post_tax_assets=post_tax_assets,
        raw_total_assets=None,
        simulated_shortfall_rate=getattr(
            portfolio_plot_data,
            "simulated_shortfall_rate",
            None,
        ),
    )