# gui_portfolio.py

import tkinter as tk
from tkinter import ttk

from warp_sim.utils.tooltip import Tooltip


class PortfolioEditFrame(ttk.Frame):
    """
    Edit portfolio data for Husband and optional Wife.
    Accepts Portfolio objects and manages StringVars internally.
    """

    def __init__(self, parent, husband_portfolio, wife_portfolio=None, title="Portfolio Data", mode="Advanced", **kwargs):
        super().__init__(parent, padding=10, **kwargs)

        style = ttk.Style()

        style.configure(
            "Derived.TEntry",
            foreground="#555555"
        )

        self._percent_keys = (
            "equity_pre",
            "equity_post",
            "bond_pre",
            "bond_post",
            "cash_pre",
            "cash_post",
        )

        self.husband_portfolio = husband_portfolio
        self.wife_portfolio = wife_portfolio

        self.mode = mode

        # ----------------------------------------
        # Derived Statistics toggle state
        # ----------------------------------------
        self._show_derived_stats_var = tk.BooleanVar(value=False)

        # Container for derived (read-only) statistics
        self.derived_frame = ttk.Frame(self, padding=10)

        # Container for inline (row-aligned) derived percentages
        self.inline_derived_frame = ttk.Frame(self)

        ttk.Label(
            self,
            text="Defines your starting assets and allocation inputs used by the simulation.",
            font=("Arial", 11),
            wraplength=600,
            justify="left",
        ).grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 8))

        self._init_vars()

        # Right-column: Percent Before / After Tax variables
        self._tax_pct_vars = {
            "pre": tk.StringVar(value="--"),
            "post": tk.StringVar(value="--"),
        }

        # Right-column: Investment Types by Percent variables
        self._inv_type_pct_vars = {
            "equities": tk.StringVar(value="--"),
            "bonds":    tk.StringVar(value="--"),
            "cash":     tk.StringVar(value="--"),
        }

        self._build_derived_layout()

        # Portfolio-level total row vars
        self._portfolio_total_vars = {
            "husband": tk.StringVar(value="--"),
            "wife":    tk.StringVar(value="--"),
            "total":   tk.StringVar(value="--"),
        }

        # Storage for total (Husband + Wife) values
        # Structure: self._total_vars[key]
        self._total_vars = {}
        
        # Storage for inline derived percentage labels
        # Structure: self._pct_labels[row_key][person]
        self._pct_labels = {}

        # Widgets for portfolio total row (shown only when derived stats enabled)
        self._portfolio_total_widgets = []

        self._build_fields()

    # ------------------------------------------------
    # Initialize temporary StringVars
    # ------------------------------------------------
    def _init_vars(self):
        def fmt(value):
            return "{:,.0f}".format(value)

        # Husband vars
        self.h_vars = {
            "equity_pre":  tk.StringVar(value=fmt(self.husband_portfolio.equity_pre)),
            "equity_post": tk.StringVar(value=fmt(self.husband_portfolio.equity_post)),
            "bond_pre":    tk.StringVar(value=fmt(self.husband_portfolio.bond_pre)),
            "bond_post":   tk.StringVar(value=fmt(self.husband_portfolio.bond_post)),
            "cash_pre":    tk.StringVar(value=fmt(self.husband_portfolio.cash_pre)),
            "cash_post":   tk.StringVar(value=fmt(self.husband_portfolio.cash_post)),
            "real_estate": tk.StringVar(value=fmt(self.husband_portfolio.real_estate)),
        }

        # Wife vars (if enabled)
        self.w_vars = None
        if self.wife_portfolio:
            self.w_vars = {
                "equity_pre":  tk.StringVar(value=fmt(self.wife_portfolio.equity_pre)),
                "equity_post": tk.StringVar(value=fmt(self.wife_portfolio.equity_post)),
                "bond_pre":    tk.StringVar(value=fmt(self.wife_portfolio.bond_pre)),
                "bond_post":   tk.StringVar(value=fmt(self.wife_portfolio.bond_post)),
                "cash_pre":    tk.StringVar(value=fmt(self.wife_portfolio.cash_pre)),
                "cash_post":   tk.StringVar(value=fmt(self.wife_portfolio.cash_post)),
                "real_estate": tk.StringVar(value=fmt(self.wife_portfolio.real_estate)),
            }

    # ------------------------------------------------
    # Build GUI
    # ------------------------------------------------
    def _build_fields(self):
        row = 1

        if self.mode == "Basic":
            # Headers
            ttk.Label(self, text="Husband", font=("Arial", 12, "bold")).grid(
                row=row, column=1, sticky="w", padx=(30, 0), pady=(10, 5)
            )
            if self.w_vars:
                ttk.Label(self, text="Wife", font=("Arial", 12, "bold")).grid(
                    row=row, column=2, sticky="w", padx=(30, 0), pady=(10, 5)
                )
            row += 1

            # Single row: Savings -> maps to cash_post
            ttk.Label(self, text="Savings").grid(row=row, column=0, sticky="w", padx=5, pady=2)

            vcmd_h = (
                self.register(self._validate_portfolio_field_on_focusout),
                "%P",
                "husband",
                "cash_post",
            )

            entry_h = ttk.Entry(
                self,
                textvariable=self.h_vars["cash_post"],
                width=14,
                validate="focusout",
                validatecommand=vcmd_h,
            )
            entry_h.grid(row=row, column=1, sticky="w", padx=5)

            if self.w_vars:
                vcmd_w = (
                    self.register(self._validate_portfolio_field_on_focusout),
                    "%P",
                    "wife",
                    "cash_post",
                )

                entry_w = ttk.Entry(
                    self,
                    textvariable=self.w_vars["cash_post"],
                    width=14,
                    validate="focusout",
                    validatecommand=vcmd_w,
                )
                entry_w.grid(row=row, column=2, sticky="w", padx=5)

            # No derived stats, no real estate, no extra notes in Basic mode
            return

        # Headers
        ttk.Label(self, text="Husband", font=("Arial", 12, "bold")).grid(
            row=row, column=1, sticky="w", padx=(30, 0), pady=(10, 5)
        )
        if self.w_vars:
            ttk.Label(self, text="Wife", font=("Arial", 12, "bold")).grid(
                row=row, column=2, sticky="w", padx=(30, 0), pady=(10, 5)
            )

        # Total header (leftmost)
        if self.w_vars:
            ttk.Label(
                self.inline_derived_frame,
                text="Total",
                font=("Arial", 12, "bold")
            ).grid(
                row=row,
                column=0,
                sticky="w",
                padx=(20, 0),
                pady=(10, 5)
            )

        # % of Full Portfolio header
        ttk.Label(
            self.inline_derived_frame,
            text="% of Full Portfolio",
            font=("Arial", 12, "bold")
        ).grid(
            row=row,
            column=1,
            columnspan=2,
            sticky="w",
            padx=(20, 0),
            pady=(10, 5)
        )

        row += 1

        fields = [
            ("Stocks Pre-Tax",  "equity_pre"),
            ("Stocks Post-Tax", "equity_post"),
            ("Bonds Pre-Tax",   "bond_pre"),
            ("Bonds Post-Tax",  "bond_post"),
            ("Cash Pre-Tax",    "cash_pre"),
            ("Cash Post-Tax",   "cash_post"),
            ("Real Estate",     "real_estate"),
        ]

        for label, key in fields:
            # Leftmost label
            ttk.Label(self, text=label).grid(row=row, column=0, sticky="w", padx=5, pady=2)

            # Husband entry
            vcmd_h = (
                self.register(self._validate_portfolio_field_on_focusout),
                "%P",
                "husband",
                key,
            )

            entry_h = ttk.Entry(
                self,
                textvariable=self.h_vars[key],
                width=14,
                validate="focusout",
                validatecommand=vcmd_h,
            )
            entry_h.grid(row=row, column=1, sticky="w", padx=5)

            # Wife entry (only if she exists)
            if self.w_vars:
                vcmd_w = (
                    self.register(self._validate_portfolio_field_on_focusout),
                    "%P",
                    "wife",
                    key,
                )

                entry_w = ttk.Entry(
                    self,
                    textvariable=self.w_vars[key],
                    width=14,
                    validate="focusout",
                    validatecommand=vcmd_w,
                )
                entry_w.grid(row=row, column=2, sticky="w", padx=5)

            # Total column
            total_var = tk.StringVar(value="--")
            total_entry = ttk.Entry(
                self.inline_derived_frame,
                textvariable=total_var,
                width=14,
                state="readonly",
                style="Derived.TEntry"
            )
            total_entry.grid(
                row=row,
                column=0,  # always leftmost in derived frame
                sticky="w",
                padx=(20, 0),
                ipady=1
            )
            self._total_vars[key] = total_var

            # Percent columns (only for % fields)
            if key in self._percent_keys:
                self._pct_labels[key] = {}

                # Husband %
                husband_pct = tk.StringVar(value="--")
                ttk.Entry(
                    self.inline_derived_frame,
                    textvariable=husband_pct,
                    width=8,
                    state="readonly",
                    style="Derived.TEntry"
                ).grid(row=row, column=1, sticky="w", padx=(20, 0), ipady=1)
                self._pct_labels[key]["husband"] = husband_pct

                # Wife % (only if she exists)
                if self.w_vars:
                    wife_pct = tk.StringVar(value="--")
                    ttk.Entry(
                        self.inline_derived_frame,
                        textvariable=wife_pct,
                        width=8,
                        state="readonly",
                        style="Derived.TEntry"
                    ).grid(row=row, column=2, sticky="w", padx=(20, 0), ipady=1)
                    self._pct_labels[key]["wife"] = wife_pct

            row += 1

        # Reserve space for portfolio total row (prevents layout bounce)
        self._portfolio_total_spacer = ttk.Label(self, text="")
        self._portfolio_total_spacer.grid(
            row=row,
            column=0,
            pady=2
        )

        # Portfolio Total row
        widgets = []

        w = ttk.Label(self, text="Total")
        w.grid(row=row, column=0, sticky="w", padx=5, pady=2)
        widgets.append(w)

        # Husband total
        w_h = ttk.Entry(
            self,
            textvariable=self._portfolio_total_vars["husband"],
            width=14,
            state="readonly",
            style="Derived.TEntry"
        )
        w_h.grid(row=row, column=1, sticky="w", padx=5)
        widgets.append(w_h)

        if self.w_vars:
            # Wife total (only if wife exists)
            w_w = ttk.Entry(
                self,
                textvariable=self._portfolio_total_vars["wife"],
                width=14,
                state="readonly",
                style="Derived.TEntry"
            )
            w_w.grid(row=row, column=2, sticky="w", padx=5)
            widgets.append(w_w)

            # Combined total (Husband + Wife)
            w_total = ttk.Entry(
                self,
                textvariable=self._portfolio_total_vars["total"],
                width=14,
                state="readonly",
                style="Derived.TEntry"
            )
            w_total.grid(row=row, column=3, sticky="w", padx=(40, 0))
            widgets.append(w_total)

        # Track widgets for show/hide
        self._portfolio_total_widgets.extend(widgets)

        # Hide them by default
        for w in widgets:
            w.grid_remove()

        self._portfolio_total_row = row

        row += 1

        style = ttk.Style()
        style.configure("DerivedCheckbutton.TCheckbutton", font=("Arial", 12))

        derived_cb = ttk.Checkbutton(
            self,
            text="Derived Statistics",
            variable=self._show_derived_stats_var,
            command=self._on_derived_stats_toggled,
            width=25,
            style="DerivedCheckbutton.TCheckbutton"  # use the style
        )
        derived_cb.grid(
            row=row,
            column=0,
            columnspan=3,
            sticky="w",
            padx=5,
            pady=(10, 5)
        )
        # Attach tooltip
        Tooltip(
            derived_cb,
            "Toggle display of derived statistics: percentages of portfolio total "
            "and investment type breakdowns. Real estate is included in totals but not percentages.",
            font=("Arial", 11)
        )

        # Optional spacer row (keeps layout neat)
        ttk.Label(self, text="").grid(row=row+1, column=0)
        row += 2

        ttk.Label(
            self,
            text=   "Note: 'Stocks' are ownership in companies.\n"
                    "          'Bonds' are debt investments that pay interest.\n"
                    "          'Cash' includes savings, CDs and money market funds.",
            font=("Arial", 12, "italic"), foreground="#555555"
        ).grid(row=row,column=0,columnspan=3,sticky="w",padx=10,pady=(0, 10) )
        row += 1

        # Remember where to place derived statistics frame
        self._derived_row_start = row


    def _parse_portfolio_field(self, field_key, raw_value):
        text = raw_value.strip().replace(",", "")

        if text == "":
            raise ValueError("Blank value is not allowed.")

        if text in {"-", "+", ".", "-.", "+."}:
            raise ValueError("Invalid number.")

        value = float(text)

        if value < 0:
            raise ValueError("Value cannot be negative.")

        return value


    def _format_portfolio_field(self, field_key, value):
        return f"{value:,.0f}"


    def _validate_portfolio_field_on_focusout(self, proposed_value, person_key, field_key):
        portfolio = self.husband_portfolio if person_key == "husband" else self.wife_portfolio
        vars_dict = self.h_vars if person_key == "husband" else self.w_vars
        var = vars_dict[field_key]

        try:
            parsed = self._parse_portfolio_field(field_key, proposed_value)
            setattr(portfolio, field_key, parsed)

            self.after_idle(
                lambda: var.set(self._format_portfolio_field(field_key, parsed))
            )
            self.after_idle(self._update_pct_of_total)
            self.after_idle(self._update_portfolio_totals)

            return True

        except ValueError:
            current_value = getattr(portfolio, field_key)

            self.after_idle(
                lambda: var.set(self._format_portfolio_field(field_key, current_value))
            )
            self.after_idle(self._update_pct_of_total)
            self.after_idle(self._update_portfolio_totals)

            self.bell()
            return True


    def _on_derived_stats_toggled(self):
        if self._show_derived_stats_var.get():
            self.inline_derived_frame.grid(
                row=1,
                column=3,
                rowspan=20,
                sticky="nw",
                padx=(20, 0)
            )

            self.derived_frame.grid(
                row=1,
                column=5,
                rowspan=20,
                sticky="nw",
                padx=(30, 0)
            )

            # Show portfolio totals row
            for w in self._portfolio_total_widgets:
                w.grid()

            self._update_pct_of_total()
            self._update_portfolio_totals()

        else:
            self.inline_derived_frame.grid_remove()
            self.derived_frame.grid_remove()

            # Hide portfolio totals row
            for w in self._portfolio_total_widgets:
                w.grid_remove()



    def _build_derived_layout(self):
        # Clear any existing widgets (safe if rebuilt)
        for child in self.derived_frame.winfo_children():
            child.destroy()

        row = 0

        # ----------------------------------------
        # Section: Percent Before / After Tax
        # ----------------------------------------
        ttk.Label(
            self.derived_frame,
            text="Percent Before / After Tax",
            font=("Arial", 12, "bold")
        ).grid(
            row=row,
            column=0,
            sticky="w",
            pady=(0, 8)
        )

        row += 1

        # % Before Tax
        ttk.Label(
            self.derived_frame,
            text="% Before Tax"
        ).grid(
            row=row,
            column=0,
            sticky="w",
            padx=5,
            pady=2
        )

        ttk.Label(
            self.derived_frame,
            textvariable=self._tax_pct_vars["pre"],
            width=12
        ).grid(
            row=row,
            column=1,
            sticky="w",
            padx=10
        )

        row += 1

        # % After Tax
        ttk.Label(
            self.derived_frame,
            text="% After Tax"
        ).grid(
            row=row,
            column=0,
            sticky="w",
            padx=5,
            pady=2
        )

        ttk.Label(
            self.derived_frame,
            textvariable=self._tax_pct_vars["post"],
            width=12
        ).grid(
            row=row,
            column=1,
            sticky="w",
            padx=10
        )

        row += 1

        # ----------------------------------------
        # Section: Investment Types by Percent
        # ----------------------------------------
        row += 1

        ttk.Label(
            self.derived_frame,
            text="Investment Types by Percent",
            font=("Arial", 12, "bold")
        ).grid(
            row=row,
            column=0,
            sticky="w",
            pady=(10, 8)
        )

        row += 1

        mapping = (
            ("Stocks", self._inv_type_pct_vars["equities"]),
            ("Bonds",    self._inv_type_pct_vars["bonds"]),
            ("Cash",     self._inv_type_pct_vars["cash"]),
        )

        for label, var in mapping:
            ttk.Label(
                self.derived_frame,
                text=label
            ).grid(
                row=row,
                column=0,
                sticky="w",
                padx=5,
                pady=2
            )

            ttk.Label(
                self.derived_frame,
                textvariable=var,
                width=12
            ).grid(
                row=row,
                column=1,
                sticky="w",
                padx=10
            )

            row += 1


    def _get_portfolio_totals(self):
        """
        Returns (combined_total, husband_total, wife_total)
        Real estate is intentionally excluded.
        """
        def sum_vars(vars_dict):
            total = 0.0
            for key in self._percent_keys:
                v = vars_dict.get(key)
                if v is None:
                    continue
                try:
                    total += float(v.get().replace(",", "").strip())
                except ValueError:
                    pass
            return total

        h_total = sum_vars(self.h_vars)
        w_total = sum_vars(self.w_vars) if self.w_vars else 0.0

        return h_total + w_total, h_total, w_total


    def _update_pct_of_total(self):
        total, _, _ = self._get_portfolio_totals()

        for key in self._percent_keys:
            labels = self._pct_labels.get(key)
            if not labels:
                continue

            # Husband %
            try:
                value = float(self.h_vars[key].get().replace(",", "").strip())
                pct = (value / total * 100.0) if total > 0 else 0.0
                labels["husband"].set(f"{pct:5.1f}%")
            except Exception:
                labels["husband"].set("--")

            # Wife % (only if exists)
            if self.w_vars and "wife" in labels:
                try:
                    value = float(self.w_vars[key].get().replace(",", "").strip())
                    pct = (value / total * 100.0) if total > 0 else 0.0
                    labels["wife"].set(f"{pct:5.1f}%")
                except Exception:
                    labels["wife"].set("--")

        self._update_totals()
        self._update_tax_pct()
        self._update_investment_type_pct()


    def _update_totals(self):
        if not self.w_vars:
            return

        def parse(vars_dict, key):
            try:
                return float(vars_dict[key].get().replace(",", "").strip())
            except Exception:
                return 0.0

        for key, var in self._total_vars.items():
            total = (
                parse(self.h_vars, key) +
                parse(self.w_vars, key)
            )
            var.set(f"{total:,.0f}")


    def _update_portfolio_totals(self):
        def parse(vars_dict):
            total = 0.0
            for v in vars_dict.values():
                try:
                    total += float(v.get().replace(",", "").strip())
                except Exception:
                    pass
            return total

        h_total = parse(self.h_vars)
        w_total = parse(self.w_vars) if self.w_vars else 0.0
        total   = h_total + w_total

        self._portfolio_total_vars["husband"].set(f"{h_total:,.0f}")
        self._portfolio_total_vars["wife"].set(f"{w_total:,.0f}" if self.w_vars else "--")
        self._portfolio_total_vars["total"].set(f"{total:,.0f}" if self.w_vars else "--")

    def _update_tax_pct(self):
        """
        Updates Percent Before / After Tax (combined household).
        Real estate is excluded.
        """
        def parse(vars_dict, key):
            try:
                return float(vars_dict[key].get().replace(",", "").strip())
            except Exception:
                return 0.0

        # Pre-tax totals
        pre_total = (
            parse(self.h_vars, "equity_pre") +
            parse(self.h_vars, "bond_pre") +
            parse(self.h_vars, "cash_pre")
        )

        post_total = (
            parse(self.h_vars, "equity_post") +
            parse(self.h_vars, "bond_post") +
            parse(self.h_vars, "cash_post")
        )

        if self.w_vars:
            pre_total += (
                parse(self.w_vars, "equity_pre") +
                parse(self.w_vars, "bond_pre") +
                parse(self.w_vars, "cash_pre")
            )

            post_total += (
                parse(self.w_vars, "equity_post") +
                parse(self.w_vars, "bond_post") +
                parse(self.w_vars, "cash_post")
            )

        total = pre_total + post_total

        if total <= 0:
            self._tax_pct_vars["pre"].set("--")
            self._tax_pct_vars["post"].set("--")
            return

        self._tax_pct_vars["pre"].set(f"{pre_total / total * 100:5.1f}%")
        self._tax_pct_vars["post"].set(f"{post_total / total * 100:5.1f}%")


    def _update_investment_type_pct(self):
        """
        Updates Investment Types by Percent (combined household).
        Real estate is excluded.
        """

        def parse(vars_dict, key):
            try:
                return float(vars_dict[key].get().replace(",", "").strip())
            except Exception:
                return 0.0

        # Husband totals
        h_equities = (
            parse(self.h_vars, "equity_pre") +
            parse(self.h_vars, "equity_post")
        )
        h_bonds = (
            parse(self.h_vars, "bond_pre") +
            parse(self.h_vars, "bond_post")
        )
        h_cash = (
            parse(self.h_vars, "cash_pre") +
            parse(self.h_vars, "cash_post")
        )

        # Wife totals (if applicable)
        w_equities = w_bonds = w_cash = 0.0
        if self.w_vars:
            w_equities = (
                parse(self.w_vars, "equity_pre") +
                parse(self.w_vars, "equity_post")
            )
            w_bonds = (
                parse(self.w_vars, "bond_pre") +
                parse(self.w_vars, "bond_post")
            )
            w_cash = (
                parse(self.w_vars, "cash_pre") +
                parse(self.w_vars, "cash_post")
            )

        # Combined household totals
        equities = h_equities + w_equities
        bonds    = h_bonds    + w_bonds
        cash     = h_cash     + w_cash

        total = equities + bonds + cash

        if total <= 0:
            self._inv_type_pct_vars["equities"].set("--")
            self._inv_type_pct_vars["bonds"].set("--")
            self._inv_type_pct_vars["cash"].set("--")
            return

        self._inv_type_pct_vars["equities"].set(f"{equities / total * 100:5.1f}%")
        self._inv_type_pct_vars["bonds"].set(f"{bonds    / total * 100:5.1f}%")
        self._inv_type_pct_vars["cash"].set(f"{cash     / total * 100:5.1f}%")
