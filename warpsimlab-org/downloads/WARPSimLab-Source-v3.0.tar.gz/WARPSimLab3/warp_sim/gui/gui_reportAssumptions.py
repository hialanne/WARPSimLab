# gui_reportAssumptions.py

from tkinter import ttk


class AssumptionsReportFrame(ttk.Frame):
    def __init__(self, parent, report_options, title="Assumptions"):
        super().__init__(parent, padding=10)

        self.options = report_options

        ttk.Label(
            self,
            text=title,
            font=("Arial", 14, "bold")
        ).grid(row=0, column=0, sticky="w", pady=(0, 8))

        ttk.Label(
            self,
            text="Assumptions report options will be added in a later step.",
            font=("Arial", 11),
            wraplength=900,
            justify="left",
        ).grid(row=1, column=0, sticky="w")