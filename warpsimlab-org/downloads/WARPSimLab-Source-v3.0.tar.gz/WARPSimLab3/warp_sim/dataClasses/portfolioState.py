# portfolioState.py

class PortfolioState:
    def __init__(self, eq_pre, bd_pre, cs_pre, eq_post, bd_post, cs_post, re_post):
        self.eq_pre = eq_pre
        self.bd_pre = bd_pre
        self.cs_pre = cs_pre
        self.eq_post = eq_post
        self.bd_post = bd_post
        self.cs_post = cs_post
        self.re_post = re_post
        self.eq_ratio_pre = 0
        self.bd_ratio_pre = 0
        self.cs_ratio_pre = 0
        self.eq_ratio_post = 0
        self.bd_ratio_post = 0
        self.cs_ratio_post = 0

    @property
    def total_value(self):
        return self.eq_pre + self.bd_pre + self.cs_pre + self.eq_post + self.bd_post + self.cs_post

    @property
    def total_value_including_real_estate(self):
        return self.eq_pre + self.bd_pre + self.cs_pre + self.eq_post + self.bd_post + self.cs_post + self.re_post

    @property
    def total_value_pre(self):
        return self.eq_pre + self.bd_pre + self.cs_pre

    @property
    def total_value_post(self):
        return self.eq_post + self.bd_post + self.cs_post

    @property
    def total_value_cash(self):
        return self.cs_pre + self.cs_post

    @property
    def total_value_bonds(self):
        return self.bd_pre + self.bd_post


