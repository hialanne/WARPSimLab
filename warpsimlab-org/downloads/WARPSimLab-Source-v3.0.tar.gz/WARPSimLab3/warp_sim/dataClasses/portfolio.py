# portfolio.py

class Portfolio:
    def __init__(self, equity_pre, equity_post, bond_pre, bond_post, cash_pre, cash_post, real_estate):
        self.equity_pre = equity_pre
        self.equity_post = equity_post
        self.bond_pre = bond_pre
        self.bond_post = bond_post
        self.cash_pre = cash_pre
        self.cash_post = cash_post
        self.real_estate = real_estate
