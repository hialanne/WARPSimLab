# withdrawalEngine.py

from warp_sim.dataClasses.portfolioState import *
from warp_sim.utils.constants import UNIFORM_LIFETIME_TABLE, RMD_START_AGE


def _get_withdrawal_inflation_factor(year, sim_config):
    historical_mode_active = (
        sim_config.subplot_mode == "monte_carlo"
        and sim_config.sim_type == "portfolio_sim"
        and getattr(sim_config, "monte_carlo_mode", "pathBasedAnnualSampling") == "rollingHistoricalWindows"
        and getattr(sim_config, "_active_historical_sim_index", None) is not None
        and getattr(sim_config, "_hist_inflation", None) is not None
    )

    if historical_mode_active:
        start_idx = int(
            sim_config._hist_window_start_indices[sim_config._active_historical_sim_index]
        )
        factor = 1.0
        for y in range(1, year + 1):
            annual_inflation = float(sim_config._hist_inflation[start_idx + (y - 1)])
            factor *= (1.0 + annual_inflation)
        return factor

    return (1.0 + sim_config.inflation_rate) ** year


def calculate_rmd(balance, age):
    """Return RMD for a given balance and age using the uniform lifetime table."""
    if age < RMD_START_AGE:
        return 0
    divisor = UNIFORM_LIFETIME_TABLE.get(age, 2.0)  # fallback for age>120
    return balance / divisor


def calculate_rmds(sim_portfolio, person, age, sim_config):
    """
    Calculate RMDs and apply them proportionally to pre-tax assets.
    Returns the RMD amount.
    """
    if not sim_config.include_rmd:
        return 0

    total_pre = sim_portfolio.eq_pre + sim_portfolio.bd_pre + sim_portfolio.cs_pre
    if total_pre <= 0:
        return 0

    rmd = calculate_rmd(total_pre, age)

    return rmd


def withdraw_rmds(sim_portfolio, rmd):
    total_pre = sim_portfolio.eq_pre + sim_portfolio.bd_pre + sim_portfolio.cs_pre
    if total_pre <= 0:
        return 0

    sim_portfolio.eq_pre -= rmd * (sim_portfolio.eq_pre / total_pre)
    sim_portfolio.bd_pre -= rmd * (sim_portfolio.bd_pre / total_pre)
    sim_portfolio.cs_pre -= rmd * (sim_portfolio.cs_pre / total_pre)

    return rmd


def calculate_retirement_withdrawal(h_port, w_port, husband, wife, year, sim_config):
    """
    Calculate retirement withdrawals based on the selected withdrawal mode.
    Withdrawals are taken first from after-tax funds, then pre-tax funds.
    If second person is enabled, withdrawals are split equally.
    RMDs are included in the total withdrawal amount.
    Portfolios never go negative.

    Returns:
        total_withdrawn: float, total amount withdrawn for the year
    """

    if not hasattr(sim_config, "_ret_withdraw_base_dollars") or sim_config._ret_withdraw_base_dollars is None:
        # Compute combined portfolio before RMDs
        total_portfolio = h_port.total_value + (w_port.total_value if sim_config.second_person_enabled else 0)
        mode = sim_config.retirement_withdraw_mode

        if mode in ["Percentage", "Percentage + Inflation"]:
            sim_config._ret_withdraw_base_dollars = total_portfolio * sim_config.retirement_withdraw_pct / 100
        elif mode in ["Fixed Dollar Amount", "Fixed Dollar Amount + Inflation"]:
            sim_config._ret_withdraw_base_dollars = sim_config.retirement_withdraw_dollars
        else:
            sim_config._ret_withdraw_base_dollars = 0.0  # Off or unknown mode

    mode = sim_config.retirement_withdraw_mode
    base = sim_config._ret_withdraw_base_dollars

    # Include RMDs
    rmd_h = calculate_rmds(h_port, husband, husband.age+year, sim_config)
    withdraw_rmds(h_port,rmd_h) 

    rmd_w = 0
    if sim_config.second_person_enabled:
        rmd_w = calculate_rmds(w_port, wife, wife.age+year, sim_config)
        withdraw_rmds(w_port, rmd_w) 

    rmd_total = rmd_h + rmd_w

    if mode == "Off":
        withdrawal_amount = rmd_total
    elif mode == "Percentage":
        withdrawal_amount = base
    elif mode == "Percentage + Inflation":
        inflation_factor = _get_withdrawal_inflation_factor(year, sim_config)
        withdrawal_amount = base * inflation_factor
    elif mode == "Fixed Dollar Amount":
        withdrawal_amount = base
    elif mode == "Fixed Dollar Amount + Inflation":
        inflation_factor = _get_withdrawal_inflation_factor(year, sim_config)
        withdrawal_amount = base * inflation_factor
    else:
        withdrawal_amount = rmd_total  # fallback

    # Ensure RMD is included
    withdrawal_amount = max(withdrawal_amount, rmd_total)
    remaining = withdrawal_amount - rmd_total

    remaining = withdrawal_amount - rmd_total
    total_withdrawn = rmd_total
    withdrawn_pre = 0.0
    withdrawn_post = 0.0

    if remaining <= 0:
        return {
            "total": total_withdrawn,
            "pre_tax": withdrawn_pre,
            "post_tax": withdrawn_post,
        }

    # Helper to choose ordering
    def order_by_bucket(p1, p2, attr):
        if getattr(p1, attr) >= getattr(p2, attr):
            return [p1, p2]
        return [p2, p1]

    def withdraw_proportionally(port, amount, tax_type):
        """
        Withdraw up to `amount` from either pre-tax or post-tax assets
        proportionally across eq/bd/cs.
        Returns the actual amount withdrawn.
        """
        nonlocal withdrawn_pre, withdrawn_post

        if amount <= 0:
            return 0.0

        if tax_type == "post":
            total = port.total_value_post
            if total <= 0:
                return 0.0

            take = min(amount, total)
            port.eq_post -= take * (port.eq_post / total)
            port.bd_post -= take * (port.bd_post / total)
            port.cs_post -= take * (port.cs_post / total)

            withdrawn_post += take
            return take

        elif tax_type == "pre":
            total = port.total_value_pre
            if total <= 0:
                return 0.0

            take = min(amount, total)
            port.eq_pre -= take * (port.eq_pre / total)
            port.bd_pre -= take * (port.bd_pre / total)
            port.cs_pre -= take * (port.cs_pre / total)

            withdrawn_pre += take
            return take

        return 0.0

    if sim_config.second_person_enabled:
        # ---- AFTER-TAX FIRST ----
        for port in order_by_bucket(h_port, w_port, "total_value_post"):
            taken = withdraw_proportionally(port, remaining, "post")
            remaining -= taken
            total_withdrawn += taken
            if remaining <= 0:
                return {
                    "total": total_withdrawn,
                    "pre_tax": withdrawn_pre,
                    "post_tax": withdrawn_post,
                }

        # ---- PRE-TAX NEXT ----
        for port in order_by_bucket(h_port, w_port, "total_value_pre"):
            taken = withdraw_proportionally(port, remaining, "pre")
            remaining -= taken
            total_withdrawn += taken
            if remaining <= 0:
                return {
                    "total": total_withdrawn,
                    "pre_tax": withdrawn_pre,
                    "post_tax": withdrawn_post,
                }

    else:
        # Single person
        taken = withdraw_proportionally(h_port, remaining, "post")
        remaining -= taken
        total_withdrawn += taken

        if remaining > 0:
            taken = withdraw_proportionally(h_port, remaining, "pre")
            remaining -= taken
            total_withdrawn += taken

    return {
        "total": total_withdrawn,
        "pre_tax": withdrawn_pre,
        "post_tax": withdrawn_post,
    }


def use_expenses_this_year(sim_config, husband, wife, year):
    """
    Determine whether manual expenses should be used for this simulation year.
    Manual expenses are used until both husband and wife are retired.

    Args:
        sim_config: Simulation configuration object
        husband: Person object
        wife: Person object
        year: int, current year of the simulation (0-based)

    Returns:
        bool: True if manual expenses should be used this year, False for retirement withdrawals
    """
    if sim_config.always_use_expense_mode:
        return True

    # Current ages
    curr_h_age = husband.age + year
    curr_w_age = wife.age + year if sim_config.second_person_enabled else 0

    # Check retirement status
    if sim_config.second_person_enabled:
        both_retired = curr_h_age >= husband.retire_age and curr_w_age >= wife.retire_age
    else:
        both_retired = curr_h_age >= husband.retire_age

    return not both_retired




