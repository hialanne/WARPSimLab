# portfolioEngine.py

import numpy as np

from warp_sim.dataClasses.portfolioState import PortfolioState

EPS = 1e-12


DEBUG_COUPLE = False  # flip False to silence
DEBUG_REBALANCE = False  # flip False to silence

# Here's how to change this flag from other files:
#if year <= 3 and s == 0:
#    portfolioEngine.DEBUG_COUPLE = True
#else:
#    portfolioEngine.DEBUG_COUPLE = False



def _clamp_post_tax_components(port):
    if port.eq_post < 0.0:
        port.eq_post = 0.0
    if port.bd_post < 0.0:
        port.bd_post = 0.0
    if port.cs_post < 0.0:
        port.cs_post = 0.0

def compute_household_allocation_targets(husband_portfolio, wife_portfolio, sim_config):
    """
    Computes the household stock/bond/cash allocation from the starting portfolios
    and stores the target ratios on sim_config.

    Rules:
    - Combine husband and wife portfolios
    - Include both pre-tax and post-tax assets
    - Exclude real estate
    - If no investable assets exist, default to 1/3 each
    """

    h_eq = husband_portfolio.equity_pre + husband_portfolio.equity_post
    h_bd = husband_portfolio.bond_pre + husband_portfolio.bond_post
    h_cs = husband_portfolio.cash_pre + husband_portfolio.cash_post

    w_eq = w_bd = w_cs = 0.0

    if sim_config.second_person_enabled and wife_portfolio is not None:
        w_eq = wife_portfolio.equity_pre + wife_portfolio.equity_post
        w_bd = wife_portfolio.bond_pre + wife_portfolio.bond_post
        w_cs = wife_portfolio.cash_pre + wife_portfolio.cash_post

    total_eq = h_eq + w_eq
    total_bd = h_bd + w_bd
    total_cs = h_cs + w_cs

    total = total_eq + total_bd + total_cs

    if total > 0:
        sim_config.household_eq_target = total_eq / total
        sim_config.household_bd_target = total_bd / total
        sim_config.household_cs_target = total_cs / total
    else:
        sim_config.household_eq_target = 1/3
        sim_config.household_bd_target = 1/3
        sim_config.household_cs_target = 1/3

def _dbg_ps(ps, name):
    print(
        f"[DBG] {name}: "
        f"post(eq={ps.eq_post:.2f}, bd={ps.bd_post:.2f}, cs={ps.cs_post:.2f}) "
        f"pre(eq={ps.eq_pre:.2f}, bd={ps.bd_pre:.2f}, cs={ps.cs_pre:.2f}) "
        f"tot_post={ps.total_value_post:.2f} tot_pre={ps.total_value_pre:.2f} tot={ps.total_value:.2f}"
    )

def _dbg_minmax(ps, name):
    vals = [ps.eq_pre, ps.bd_pre, ps.cs_pre, ps.eq_post, ps.bd_post, ps.cs_post]
    print(
        f"[DBG] {name}: tot_post={ps.total_value_post:.6f} tot_pre={ps.total_value_pre:.6f} "
        f"min_component={min(vals):.12f} max_component={max(vals):.6f} "
        f"post(eq={ps.eq_post:.6f}, bd={ps.bd_post:.6f}, cs={ps.cs_post:.6f})"
    )

# ----------------------------
# Core Portfolio Functions
# ----------------------------

def initialize_portfolio(equity_pre, bond_pre, cash_pre, equity_post, bond_post, cash_post):
    """
    Initializes and returns the portfolio values for the simulation.
    """
    return equity_pre, bond_pre, cash_pre, equity_post, bond_post, cash_post


def create_sim_portfolio(portfolio, sim_config=None):
    """
    Initializes a PortfolioState from a Portfolio object and applies rebalancing based on sim_rebalance flag.
    """
    sim_portfolio = PortfolioState(
        eq_pre=portfolio.equity_pre,
        bd_pre=portfolio.bond_pre,
        cs_pre=portfolio.cash_pre,
        eq_post=portfolio.equity_post,
        bd_post=portfolio.bond_post,
        cs_post=portfolio.cash_post,
        re_post=getattr(portfolio, 'real_estate', 0.0) if sim_config.include_realestate else 0.0
    )

    if sim_config.sim_rebalance == "maintain-current-allocation":

        eq_t = getattr(sim_config, "household_eq_target", 1/3)
        bd_t = getattr(sim_config, "household_bd_target", 1/3)
        cs_t = getattr(sim_config, "household_cs_target", 1/3)

        total_pre = sim_portfolio.eq_pre + sim_portfolio.bd_pre + sim_portfolio.cs_pre
        total_post = sim_portfolio.eq_post + sim_portfolio.bd_post + sim_portfolio.cs_post

        if total_pre > 0:
            sim_portfolio.eq_pre = total_pre * eq_t
            sim_portfolio.bd_pre = total_pre * bd_t
            sim_portfolio.cs_pre = total_pre * cs_t

        if total_post > 0:
            sim_portfolio.eq_post = total_post * eq_t
            sim_portfolio.bd_post = total_post * bd_t
            sim_portfolio.cs_post = total_post * cs_t

        return sim_portfolio

    if sim_config.sim_rebalance == "dont-rebalance":
        total_pre = sim_portfolio.eq_pre + sim_portfolio.bd_pre + sim_portfolio.cs_pre
        total_post = sim_portfolio.eq_post + sim_portfolio.bd_post + sim_portfolio.cs_post

        sim_portfolio.eq_ratio_pre = sim_portfolio.eq_pre / total_pre if total_pre > 0 else 0
        sim_portfolio.bd_ratio_pre = sim_portfolio.bd_pre / total_pre if total_pre > 0 else 0
        sim_portfolio.cs_ratio_pre = sim_portfolio.cs_pre / total_pre if total_pre > 0 else 0

        sim_portfolio.eq_ratio_post = sim_portfolio.eq_post / total_post if total_post > 0 else 0
        sim_portfolio.bd_ratio_post = sim_portfolio.bd_post / total_post if total_post > 0 else 0
        sim_portfolio.cs_ratio_post = sim_portfolio.cs_post / total_post if total_post > 0 else 0

        return sim_portfolio

    rebalance_ratios = {
        "30-30-40": {"equity": 0.30, "bonds": 0.30, "cash": 0.40},
        "50-30-20": {"equity": 0.50, "bonds": 0.30, "cash": 0.20},
        "70-20-10": {"equity": 0.70, "bonds": 0.20, "cash": 0.10},
    }

    if sim_config.sim_rebalance == "custom":
        total_pre = sim_portfolio.eq_pre + sim_portfolio.bd_pre + sim_portfolio.cs_pre
        total_post = sim_portfolio.eq_post + sim_portfolio.bd_post + sim_portfolio.cs_post

        if total_pre > 0:
            sim_portfolio.eq_pre = total_pre * sim_config.custom_stock
            sim_portfolio.bd_pre = total_pre * sim_config.custom_bonds
            sim_portfolio.cs_pre = total_pre * sim_config.custom_cash

        if total_post > 0:
            sim_portfolio.eq_post = total_post * sim_config.custom_stock
            sim_portfolio.bd_post = total_post * sim_config.custom_bonds
            sim_portfolio.cs_post = total_post * sim_config.custom_cash

        return sim_portfolio

    if sim_config.sim_rebalance in rebalance_ratios:
        rebalance = rebalance_ratios[sim_config.sim_rebalance]
        total_pre = sim_portfolio.eq_pre + sim_portfolio.bd_pre + sim_portfolio.cs_pre
        total_post = sim_portfolio.eq_post + sim_portfolio.bd_post + sim_portfolio.cs_post

        if total_pre > 0:
            sim_portfolio.eq_pre = total_pre * rebalance["equity"]
            sim_portfolio.bd_pre = total_pre * rebalance["bonds"]
            sim_portfolio.cs_pre = total_pre * rebalance["cash"]

        if total_post > 0:
            sim_portfolio.eq_post = total_post * rebalance["equity"]
            sim_portfolio.bd_post = total_post * rebalance["bonds"]
            sim_portfolio.cs_post = total_post * rebalance["cash"]

    return sim_portfolio


def estimate_post_tax_income_components(sim_portfolio, sim_config):
    equity_div_yield = sim_config._post_tax_equity_dividend_yield
    bond_yield = sim_config._post_tax_bond_interest_yield
    cash_yield = sim_config._post_tax_cash_interest_yield

    eq_post = sim_portfolio.eq_post
    bd_post = sim_portfolio.bd_post
    cs_post = sim_portfolio.cs_post

    qualified_dividends = eq_post * equity_div_yield
    bond_interest = bd_post * bond_yield
    cash_interest = cs_post * cash_yield

    ordinary_total = bond_interest + cash_interest
    total = ordinary_total + qualified_dividends

    return {
        "bond_interest": bond_interest,
        "cash_interest": cash_interest,
        "qualified_dividends": qualified_dividends,
        "ordinary_total": ordinary_total,
        "qualified_total": qualified_dividends,
        "total": total,
    }


def apply_post_tax_income_components_to_income(income, post_tax_income, second_person_enabled):
    """
    Apply estimated household post-tax income components into the simulation's
    structured income dictionary.

    Group 1 behavior:
      - bond interest, cash interest, and qualified dividends are all added to
        income["total"]
      - Group 2 will split ordinary vs qualified tax handling more precisely
    """
    income["by_class"]["bond_interest"] += post_tax_income["bond_interest"]
    income["by_class"]["cash_interest"] += post_tax_income["cash_interest"]
    income["by_class"]["qualified_dividends"] += post_tax_income["qualified_dividends"]

    income["by_person"]["husband"] += post_tax_income["by_person"]["husband"]["total"]
    if second_person_enabled:
        income["by_person"]["wife"] += post_tax_income["by_person"]["wife"]["total"]

    income["total"] += post_tax_income["total"]

    return income

def estimate_household_post_tax_income_components(h_port, w_port, sim_config):
    eq_yield = sim_config._post_tax_equity_dividend_yield
    bd_yield = sim_config._post_tax_bond_interest_yield
    cs_yield = sim_config._post_tax_cash_interest_yield

    h_qd = h_port.eq_post * eq_yield
    h_bi = h_port.bd_post * bd_yield
    h_ci = h_port.cs_post * cs_yield
    h_total = h_qd + h_bi + h_ci

    if sim_config.second_person_enabled:
        w_qd = w_port.eq_post * eq_yield
        w_bi = w_port.bd_post * bd_yield
        w_ci = w_port.cs_post * cs_yield
        w_total = w_qd + w_bi + w_ci
    else:
        w_qd = 0.0
        w_bi = 0.0
        w_ci = 0.0
        w_total = 0.0

    bond_interest = h_bi + w_bi
    cash_interest = h_ci + w_ci
    qualified_dividends = h_qd + w_qd

    # --- Clamp tiny floating-point negatives ---
    EPS = 1e-12
    if -EPS < bond_interest < 0.0:
        bond_interest = 0.0
    if -EPS < cash_interest < 0.0:
        cash_interest = 0.0
    if -EPS < qualified_dividends < 0.0:
        qualified_dividends = 0.0

    total = bond_interest + cash_interest + qualified_dividends

    return (
        bond_interest,
        cash_interest,
        qualified_dividends,
        total,
        h_total,
        w_total,
    )


def apply_returns_and_fund_expenses(
    sim_portfolio,
    eq_return,
    bd_return,
    cs_return,
    re_return,
    fund_expense,
):
    eq_pre = sim_portfolio.eq_pre
    bd_pre = sim_portfolio.bd_pre
    cs_pre = sim_portfolio.cs_pre
    eq_post = sim_portfolio.eq_post
    bd_post = sim_portfolio.bd_post
    cs_post = sim_portfolio.cs_post
    re_post = sim_portfolio.re_post

    eq_mult = 1.0 + eq_return
    bd_mult = 1.0 + bd_return
    cs_mult = 1.0 + cs_return
    re_mult = 1.0 + re_return
    exp_mult = 1.0 - fund_expense

    eq_pre *= eq_mult
    bd_pre *= bd_mult
    cs_pre *= cs_mult
    eq_post *= eq_mult
    bd_post *= bd_mult
    cs_post *= cs_mult
    re_post *= re_mult

    total_before = (
        eq_pre + bd_pre + cs_pre +
        eq_post + bd_post + cs_post
    )

    eq_pre *= exp_mult
    bd_pre *= exp_mult
    cs_pre *= exp_mult
    eq_post *= exp_mult
    bd_post *= exp_mult
    cs_post *= exp_mult

    fund_expenses = total_before * fund_expense

    sim_portfolio.eq_pre = eq_pre
    sim_portfolio.bd_pre = bd_pre
    sim_portfolio.cs_pre = cs_pre
    sim_portfolio.eq_post = eq_post
    sim_portfolio.bd_post = bd_post
    sim_portfolio.cs_post = cs_post
    sim_portfolio.re_post = re_post

    _clamp_post_tax_components(sim_portfolio)

    return fund_expenses


def apply_returns(sim_portfolio, eq_return, bd_return, cs_return, re_return):
    """
    Apply already-determined returns to a portfolio.

    This function is intentionally deterministic.
    It does not sample randomness internally.

    Parameters
    ----------
    sim_portfolio : PortfolioState
        The portfolio state to update in place.
    eq_return : float
        Equity return for the current simulation-year.
    bd_return : float
        Bond return for the current simulation-year.
    cs_return : float
        Cash return for the current simulation-year.
    re_return : float
        Real estate return for the current simulation-year.
    """

    sim_portfolio.eq_pre += sim_portfolio.eq_pre * eq_return
    sim_portfolio.bd_pre += sim_portfolio.bd_pre * bd_return
    sim_portfolio.cs_pre += sim_portfolio.cs_pre * cs_return

    sim_portfolio.eq_post += sim_portfolio.eq_post * eq_return
    sim_portfolio.bd_post += sim_portfolio.bd_post * bd_return
    sim_portfolio.cs_post += sim_portfolio.cs_post * cs_return

    sim_portfolio.re_post += sim_portfolio.re_post * re_return

    # This code is slowing down monte carlo slightly.  I'm pretty sure we
    #   never come in here with a negative return, thus we should be oK.
    

def apply_fund_expenses(sim_portfolio, fund_expense):
    """
    Reduce the portfolio components proportionally by the fund expense (0-1).
    Returns the dollar amount removed.
    """

    total_before = (
        sim_portfolio.eq_pre  +
        sim_portfolio.bd_pre  +
        sim_portfolio.cs_pre  +
        sim_portfolio.eq_post +
        sim_portfolio.bd_post +
        sim_portfolio.cs_post
    )

    deltaFundExpenses = 1 - fund_expense
    sim_portfolio.eq_pre  *= deltaFundExpenses
    sim_portfolio.bd_pre  *= deltaFundExpenses
    sim_portfolio.cs_pre  *= deltaFundExpenses
    sim_portfolio.eq_post *= deltaFundExpenses
    sim_portfolio.bd_post *= deltaFundExpenses
    sim_portfolio.cs_post *= deltaFundExpenses

    total_after = (
        sim_portfolio.eq_pre  +
        sim_portfolio.bd_pre  +
        sim_portfolio.cs_pre  +
        sim_portfolio.eq_post +
        sim_portfolio.bd_post +
        sim_portfolio.cs_post
    )

    total = total_before - total_after

    if total > 0.0:
        return total
    else:
        return 0.0


def rebalance(sim_portfolio, sim_config):
    """
    Rebalance the existing portfolio (in-place) based on strategy used in create_sim_portfolio.
    """
    if DEBUG_REBALANCE:
        print(
            f"[DBG] rebalance ENTER: sim_rebalance={sim_config.sim_rebalance} "
            f"post={sim_portfolio.total_value_post:.6f} "
            f"ratios_post=({sim_portfolio.eq_ratio_post:.6f}, {sim_portfolio.bd_ratio_post:.6f}, {sim_portfolio.cs_ratio_post:.6f}) "
            f"holdings_post=({sim_portfolio.eq_post:.6f}, {sim_portfolio.bd_post:.6f}, {sim_portfolio.cs_post:.6f})"
        )


    if sim_config.sim_rebalance == "maintain-current-allocation":
        eq_ratio_pre = eq_ratio_post = sim_config.household_eq_target
        bd_ratio_pre = bd_ratio_post = sim_config.household_bd_target
        cs_ratio_pre = cs_ratio_post = sim_config.household_cs_target

    elif sim_config.sim_rebalance == "dont-rebalance":
        # If ratios were never initialized (e.g., started with total_post==0), recompute
        s = sim_portfolio.eq_ratio_post + sim_portfolio.bd_ratio_post + sim_portfolio.cs_ratio_post
        if s <= 1e-12 and sim_portfolio.total_value_post > 1e-9:
            total_post = sim_portfolio.total_value_post
            sim_portfolio.eq_ratio_post = sim_portfolio.eq_post / total_post
            sim_portfolio.bd_ratio_post = sim_portfolio.bd_post / total_post
            sim_portfolio.cs_ratio_post = sim_portfolio.cs_post / total_post

        s = sim_portfolio.eq_ratio_pre + sim_portfolio.bd_ratio_pre + sim_portfolio.cs_ratio_pre
        if s <= 1e-12 and sim_portfolio.total_value_pre > 1e-9:
            total_pre = sim_portfolio.total_value_pre
            sim_portfolio.eq_ratio_pre = sim_portfolio.eq_pre / total_pre
            sim_portfolio.bd_ratio_pre = sim_portfolio.bd_pre / total_pre
            sim_portfolio.cs_ratio_pre = sim_portfolio.cs_pre / total_pre

        eq_ratio_pre = sim_portfolio.eq_ratio_pre
        bd_ratio_pre = sim_portfolio.bd_ratio_pre
        cs_ratio_pre = sim_portfolio.cs_ratio_pre
        eq_ratio_post = sim_portfolio.eq_ratio_post
        bd_ratio_post = sim_portfolio.bd_ratio_post
        cs_ratio_post = sim_portfolio.cs_ratio_post
    elif sim_config.sim_rebalance == "custom":
        eq_ratio_pre = eq_ratio_post = sim_config.custom_stock
        bd_ratio_pre = bd_ratio_post = sim_config.custom_bonds
        cs_ratio_pre = cs_ratio_post = sim_config.custom_cash
    else:
        rebalance_ratios = {
            "30-30-40": {"equity": 0.30, "bonds": 0.30, "cash": 0.40},
            "50-30-20": {"equity": 0.50, "bonds": 0.30, "cash": 0.20},
            "70-20-10": {"equity": 0.70, "bonds": 0.20, "cash": 0.10},
        }
        if sim_config.sim_rebalance in rebalance_ratios:
            ratios = rebalance_ratios[sim_config.sim_rebalance]
            eq_ratio_pre = eq_ratio_post = ratios["equity"]
            bd_ratio_pre = bd_ratio_post = ratios["bonds"]
            cs_ratio_pre = cs_ratio_post = ratios["cash"]
        else:
            # There should be a warning here.  We should never get here.
            print("Bad, bad, bad in rebalance")
            return

    if DEBUG_REBALANCE:
        print(
            f"[DBG] rebalance RATIOS USED: "
            f"post_ratios=({eq_ratio_post:.6f}, {bd_ratio_post:.6f}, {cs_ratio_post:.6f}) "
            f"sum={eq_ratio_post+bd_ratio_post+cs_ratio_post:.6f}"
        )

    total_pre = sim_portfolio.eq_pre + sim_portfolio.bd_pre + sim_portfolio.cs_pre
    if total_pre > 0:
        sim_portfolio.eq_pre = total_pre * eq_ratio_pre
        sim_portfolio.bd_pre = total_pre * bd_ratio_pre
        sim_portfolio.cs_pre = total_pre * cs_ratio_pre

    total_post = sim_portfolio.eq_post + sim_portfolio.bd_post + sim_portfolio.cs_post
    if total_post > 0:
        sim_portfolio.eq_post = total_post * eq_ratio_post
        sim_portfolio.bd_post = total_post * bd_ratio_post
        sim_portfolio.cs_post = total_post * cs_ratio_post

    # End of rebalance()
    # I'm pretty sure that rebalance won't create a zero.  This is slowing
    #   down monte carlo code.  Commenting it out.

    if DEBUG_REBALANCE:
        print(
            f"[DBG] rebalance EXIT: post={sim_portfolio.total_value_post:.6f} "
            f"holdings_post=({sim_portfolio.eq_post:.6f}, {sim_portfolio.bd_post:.6f}, {sim_portfolio.cs_post:.6f})"
        )

    # if DEBUG_COUPLE:
    #     _dbg_minmax(sim_portfolio, "AFTER rebalance()")

def apply_net_income_proportionally(sim_portfolio, net_change):
    """
    Applies net change proportionally to sim_portfolio components.
    Note we only apply this to the after tax portfolio
    """
    total_portfolio_post = sim_portfolio.total_value_post
    if total_portfolio_post > 0:
        sim_portfolio.eq_post += net_change * (sim_portfolio.eq_post / total_portfolio_post)
        sim_portfolio.bd_post += net_change * (sim_portfolio.bd_post / total_portfolio_post)
        sim_portfolio.cs_post += net_change * (sim_portfolio.cs_post / total_portfolio_post)
    else:
        # Badness.  We didn't have initial post tax money to form ratios.  If possible, use pre.
        total_portfolio_pre = sim_portfolio.total_value_pre
        if total_portfolio_pre > 0:
            sim_portfolio.eq_post += net_change * (sim_portfolio.eq_pre / total_portfolio_pre)
            sim_portfolio.bd_post += net_change * (sim_portfolio.bd_pre / total_portfolio_pre)
            sim_portfolio.cs_post += net_change * (sim_portfolio.cs_pre / total_portfolio_pre)
        else:
            sim_portfolio.eq_post = net_change * 1/3
            sim_portfolio.bd_post = net_change * 1/3
            sim_portfolio.cs_post = net_change * 1/3

    # --- Safety clamp (diagnostic) ---
    if sim_portfolio.eq_post < 0.0:
        sim_portfolio.eq_post = 0.0

    if sim_portfolio.bd_post < 0.0:
        sim_portfolio.bd_post = 0.0

    if sim_portfolio.cs_post < 0.0:
        sim_portfolio.cs_post = 0.0

    return sim_portfolio.total_value


def apply_net_income_proportionally_pre(sim_portfolio, net_change):
    """
    Applies net change proportionally to sim_portfolio components.
    Note we only apply this to the after tax portfolio
    """
    total_portfolio_pre = sim_portfolio.total_value_pre
    if total_portfolio_pre > 0:
        sim_portfolio.eq_pre += net_change * (sim_portfolio.eq_pre / total_portfolio_pre)
        sim_portfolio.bd_pre += net_change * (sim_portfolio.bd_pre / total_portfolio_pre)
        sim_portfolio.cs_pre += net_change * (sim_portfolio.cs_pre / total_portfolio_pre)
    else:
        print("SHOULD NEVER BE HERE - apply_net_income_proportionally_pre")
        sim_portfolio.eq_pre = net_change * 1/3
        sim_portfolio.bd_pre = net_change * 1/3
        sim_portfolio.cs_pre = net_change * 1/3

    if sim_portfolio.eq_pre < 0.0:
        sim_portfolio.eq_pre = 0.0

    if sim_portfolio.bd_pre < 0.0:
        sim_portfolio.bd_pre = 0.0

    if sim_portfolio.cs_pre < 0.0:
        sim_portfolio.cs_pre = 0.0

    return sim_portfolio.total_value


def create_empty_sim_portfolio(sim_config):
    """
    Returns a zero-valued PortfolioState for disabled second person.
    """
    return PortfolioState(
        eq_pre=0.0,
        bd_pre=0.0,
        cs_pre=0.0,
        eq_post=0.0,
        bd_post=0.0,
        cs_post=0.0,
        re_post=0.0 if sim_config.include_realestate else 0.0
    )

def get_pre_tax_ratios(sim_portfolio):
    """
    Returns current pre-tax allocation ratios.
    """
    total_pre = sim_portfolio.eq_pre + sim_portfolio.bd_pre + sim_portfolio.cs_pre

    if total_pre > 0:
        return {
            "equity": sim_portfolio.eq_pre / total_pre,
            "bonds": sim_portfolio.bd_pre / total_pre,
            "cash": sim_portfolio.cs_pre / total_pre,
        }

    # Fallback if portfolio is empty
    return {
        "equity": 1/3,
        "bonds": 1/3,
        "cash": 1/3,
    }

def apply_pre_tax_contribution(sim_portfolio, amount):
    """
    Applies a pre-tax contribution to a portfolio in-place.
    Allocation is proportional to existing pre-tax assets.
    """
    if amount <= 0:
        return

    total_pre = sim_portfolio.eq_pre + sim_portfolio.bd_pre + sim_portfolio.cs_pre

    if total_pre > 0:
        sim_portfolio.eq_pre += amount * (sim_portfolio.eq_pre / total_pre)
        sim_portfolio.bd_pre += amount * (sim_portfolio.bd_pre / total_pre)
        sim_portfolio.cs_pre += amount * (sim_portfolio.cs_pre / total_pre)
    else:
        sim_portfolio.eq_pre += amount * 1/3
        sim_portfolio.bd_pre += amount * 1/3
        sim_portfolio.cs_pre += amount * 1/3


def deduct_post_tax_amount(h_port, w_port, amount, sim_config):
    """
    Deduct a dollar amount from household post-tax assets.

    This is a pure asset-movement helper. It does not compute taxes.
    It removes funds proportionally from post-tax assets across the
    household and within each portfolio across eq/bd/cs post.

    Returns:
        actual_deducted (float): amount successfully removed
    """
    amount = float(max(amount, 0.0))
    if amount <= 0:
        return 0.0

    second_person_enabled = getattr(sim_config, "second_person_enabled", True)

    if h_port.total_value_post < 0.0:
        h_post = 0.0
    else:
        h_post = h_port.total_value_post

    if second_person_enabled:
        if w_port.total_value_post < 0.0:
            w_post = 0.0
        else:
            w_post = w_port.total_value_post
    else:
        w_post = 0.0

    total_post = h_post + w_post

    if total_post <= 0:
        return 0.0

    if amount <= total_post:
        to_take = amount
    else:
        to_take = total_post

    h_take = to_take * (h_post / total_post) if h_post > 0 else 0.0
    w_take = to_take - h_take if second_person_enabled else 0.0

    def deduct_from_one_port(port, take):
        take = float(max(take, 0.0))
        total = max(port.total_value_post, 0.0)
        if take <= 0 or total <= 0:
            return 0.0

        if take <= total:
            actual = take
        else:
            actual = total

        ratio = actual / total

        port.eq_post -= port.eq_post * ratio
        port.bd_post -= port.bd_post * ratio
        port.cs_post -= port.cs_post * ratio

        # safety clamp
        if port.eq_post < 0.0:
            port.eq_post = 0.0

        if port.bd_post < 0.0:
            port.bd_post = 0.0

        if port.cs_post < 0.0:
            port.cs_post = 0.0

        return actual

    deducted = 0.0
    deducted += deduct_from_one_port(h_port, h_take)

    if second_person_enabled:
        deducted += deduct_from_one_port(w_port, w_take)

    return deducted

    
# NOTE ON PRE-TAX WITHDRAWALS
# ---------------------------
# These net-income functions move assets only.
# If a deficit requires drawing from pre-tax assets, the functions return the
# gross pre-tax amount withdrawn.
#
# Taxes on that pre-tax withdrawal are NOT estimated here.
# They are computed later in run_sim_core.py by adding the gross withdrawal
# into ordinary income and then running the tax engine.
#
# This uses a one-pass approximation:
#   1. determine cash deficit and gross asset withdrawals
#   2. compute/recompute taxes using the gross pre-tax withdrawal
#
# This avoids embedding tax law assumptions inside portfolioEngine.

def apply_net_income_couple(h_port, w_port, net_cash):
    """
    Apply net household cash flow to a couple's portfolios.

    Surplus income is added to post-tax assets.

    Deficits are covered in this order:

        1. household post-tax assets
        2. household pre-tax assets

    The function returns the gross amount withdrawn from pre-tax assets
    so the simulation loop can include it in taxable income.

    See apply_net_income_single() for detailed discussion of the one-pass
    tax approximation used by the simulator.
    """

    result = {
        "post_tax_used": 0.0,
        "pre_tax_used": 0.0,
        "uncovered": 0.0,
    }

    if net_cash >= 0:
        half = net_cash / 2
        h_port.eq_post += half
        w_port.eq_post += half
        return result

    deficit = -net_cash

    # -----------------------
    # Post-tax assets
    # -----------------------
    total_post = h_port.total_value_post + w_port.total_value_post

    if deficit <= total_post:
        use_post = deficit
    else:
        use_post = total_post

    if use_post > 0:

        h_ratio = h_port.total_value_post / total_post if total_post > 0 else 0
        w_ratio = w_port.total_value_post / total_post if total_post > 0 else 0

        h_use = use_post * h_ratio
        w_use = use_post * w_ratio

        if h_port.total_value_post > 0:
            r = h_use / h_port.total_value_post
            h_port.eq_post -= h_port.eq_post * r
            h_port.bd_post -= h_port.bd_post * r
            h_port.cs_post -= h_port.cs_post * r

        if w_port.total_value_post > 0:
            r = w_use / w_port.total_value_post
            w_port.eq_post -= w_port.eq_post * r
            w_port.bd_post -= w_port.bd_post * r
            w_port.cs_post -= w_port.cs_post * r

        deficit -= use_post
        result["post_tax_used"] = use_post

    # -----------------------
    # Pre-tax assets
    # -----------------------
    if deficit > 0:

        total_pre = h_port.total_value_pre + w_port.total_value_pre

        if deficit <= total_pre:
            use_pre = deficit
        else:
            use_pre = total_pre

        if use_pre > 0:

            h_ratio = h_port.total_value_pre / total_pre if total_pre > 0 else 0
            w_ratio = w_port.total_value_pre / total_pre if total_pre > 0 else 0

            h_use = use_pre * h_ratio
            w_use = use_pre * w_ratio

            if h_port.total_value_pre > 0:
                r = h_use / h_port.total_value_pre
                h_port.eq_pre -= h_port.eq_pre * r
                h_port.bd_pre -= h_port.bd_pre * r
                h_port.cs_pre -= h_port.cs_pre * r

            if w_port.total_value_pre > 0:
                r = w_use / w_port.total_value_pre
                w_port.eq_pre -= w_port.eq_pre * r
                w_port.bd_pre -= w_port.bd_pre * r
                w_port.cs_pre -= w_port.cs_pre * r

            deficit -= use_pre
            result["pre_tax_used"] = use_pre

    if deficit > 0:
        result["uncovered"] = deficit

    _clamp_post_tax_components(h_port)
    _clamp_post_tax_components(w_port)

    return result



def apply_net_income_single(port, net_cash):
    """
    Apply yearly net cash flow to a single portfolio.

    Positive net_cash:
        Surplus income added to post-tax assets.

    Negative net_cash:
        Cash deficit that must be funded by withdrawing assets.

    Withdrawal order:
        1. post-tax assets
        2. pre-tax assets

    IMPORTANT DESIGN NOTE
    ---------------------
    This function intentionally does NOT estimate taxes on pre-tax withdrawals.

    Instead, it returns the gross amount withdrawn from pre-tax accounts so
    the simulation loop (run_sim_core) can include that amount in taxable
    income and let the tax engine compute the correct tax.

    This avoids the previous behavior where portfolioEngine guessed taxes
    using a flat rate.

    ONE-PASS TAX APPROXIMATION
    --------------------------
    When pre-tax assets are used to cover a deficit, the resulting tax
    liability will increase household taxes for the year.

    The simulator uses a one-pass approximation:

        1. Estimate taxes
        2. Determine asset withdrawals
        3. Recompute taxes including the pre-tax withdrawal

    This avoids the circular dependency:

        deficit > withdrawal > taxes > larger deficit

    while keeping the model simple and stable.
    """

    result = {
        "post_tax_used": 0.0,
        "pre_tax_used": 0.0,
        "uncovered": 0.0,
    }
    # -----------------------
    # Positive net cash flow
    # -----------------------
    if net_cash >= 0:
        port.eq_post += net_cash
        return result

    deficit = -net_cash

    # -----------------------
    # Use post-tax assets first
    # -----------------------
    available_post = port.total_value_post

    if deficit <= available_post:
        use_post = deficit
    else:
        use_post = available_post

    if use_post > 0:
        ratio = use_post / available_post if available_post > 0 else 0

        port.eq_post -= port.eq_post * ratio
        port.bd_post -= port.bd_post * ratio
        port.cs_post -= port.cs_post * ratio

        deficit -= use_post
        result["post_tax_used"] = use_post

    # -----------------------
    # Use pre-tax assets next
    # -----------------------
    if deficit > 0:

        available_pre = port.total_value_pre

        if deficit <= available_pre:
            use_pre = deficit
        else:
            use_pre = available_pre

        if use_pre > 0:

            ratio = use_pre / available_pre if available_pre > 0 else 0

            port.eq_pre -= port.eq_pre * ratio
            port.bd_pre -= port.bd_pre * ratio
            port.cs_pre -= port.cs_pre * ratio

            deficit -= use_pre
            result["pre_tax_used"] = use_pre

    # -----------------------
    # Remaining deficit
    # -----------------------
    if deficit > 0:
        result["uncovered"] = deficit

    _clamp_post_tax_components(port)
    
    return result    