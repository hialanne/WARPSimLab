# warp_sim/sim/run_sim_income.py

from .simulation import run_pipeline
from warp_sim.plots.plotYearlyIncome import plot_yearly_income
from warp_sim.plots import io  # ensure io.py is imported


def run_sim_income(husband_portfolio, wife_portfolio, husband, wife, expenses, sim_config):
    """
    Run a yearly income-focused simulation using the canonical pipeline.
    """

    # Income mode is deterministic
    p = run_pipeline(
        husband_portfolio,
        wife_portfolio,
        husband,
        wife,
        expenses,
        sim_config,
        force_num_sims=1
    )

    # Plot
    plot_yearly_income(
        p["years"],
        net_profit=p["net_profit"],
        net_income=p["net_income"],
        breakdown=p["breakdown_by_class"],
        taxes=p["taxes"],
        expenses=p["expense_amt"],
        husband=husband,
        wife=wife,
        sim_config=sim_config
    )

    # Optional CSV output
    if sim_config.output_csv == "Output":
        csv_file = io.write_income_results_csv(
            p["years_list"],
            p["net_income"],
            p["net_profit"],
            p["taxes"],
            p["breakdown_by_class"],
            sim_config,
            prefix="income_simulation"
        )
        if csv_file:
            print(f"Income simulation results written to: {csv_file}")